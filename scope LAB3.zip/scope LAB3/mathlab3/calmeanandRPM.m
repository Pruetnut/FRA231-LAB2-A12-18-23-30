rawF = [458.7, 458.7, 454.5];
F40i = mean(rawF);
RPM40i = (F40i * 120) / 14;

rawF = [662.3, 662.3, 666.7];
F60i = mean(rawF);
RPM60i = (F60i * 120) / 14;

rawF = [912.4, 922.5, 925.9];
F80i = mean(rawF);
RPM80i = (F80i * 120) / 14;

rawF = [1136, 1142, 1166];
F100i = mean(rawF);
RPM100i = (F100i * 120) / 14;

RPMar = [RPM20, RPM40, RPM60, RPM80, RPM100];